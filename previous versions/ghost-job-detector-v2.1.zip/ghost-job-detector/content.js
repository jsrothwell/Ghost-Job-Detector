// Ghost Job Detector - Content Script

// Known ghost job companies (starter list - can be updated from GhostJobs.io)
let ghostJobCompanies = [];
let companyAliases = {};
let showPositiveIndicator = true;

// Load the ghost job companies list from storage
chrome.storage.local.get(['ghostJobCompanies', 'companyAliases', 'lastUpdated', 'darkMode', 'showPositiveIndicator'], (result) => {
  if (result.ghostJobCompanies) {
    ghostJobCompanies = result.ghostJobCompanies;
    companyAliases = result.companyAliases || {};
    console.log('Loaded ghost job companies:', ghostJobCompanies.length);
  }
  
  // Load positive indicator setting (default true)
  showPositiveIndicator = result.showPositiveIndicator !== false;
  
  // Check if we need to update the list (update every 24 hours)
  const lastUpdated = result.lastUpdated || 0;
  const dayInMs = 24 * 60 * 60 * 1000;
  
  if (Date.now() - lastUpdated > dayInMs) {
    chrome.runtime.sendMessage({ action: 'updateGhostJobList' });
  }
  
  // Start checking for ghost jobs
  checkForGhostJobs();
});

// Extract company name from different job sites
function extractCompanyName() {
  const url = window.location.hostname;
  let companyName = '';
  
  if (url.includes('linkedin.com')) {
    // LinkedIn selectors
    const selectors = [
      '.job-details-jobs-unified-top-card__company-name a',
      '.job-details-jobs-unified-top-card__company-name',
      '.jobs-unified-top-card__company-name a',
      '.jobs-unified-top-card__company-name',
      '.topcard__org-name-link',
      '.topcard__flavor--black-link'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('indeed.com')) {
    // Indeed selectors
    const selectors = [
      '[data-company-name="true"]',
      '.jobsearch-CompanyInfoContainer a',
      '.jobsearch-InlineCompanyRating-companyHeader a',
      '[class*="companyName"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('glassdoor.com')) {
    // Glassdoor selectors
    const selectors = [
      '[data-test="employer-name"]',
      '.employerName',
      '[class*="EmployerProfile_employerName"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('ziprecruiter.com')) {
    // ZipRecruiter selectors
    const selectors = [
      '[class*="CompanyName"]',
      'a.company_name'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('wellfound.com')) {
    // Wellfound (AngelList) selectors
    const selectors = [
      '[class*="company"]',
      'a[href*="/company/"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && element.href && element.href.includes('/company/')) {
        companyName = element.textContent.trim();
        break;
      }
    }
  }
  
  return companyName;
}

// Extract job posting date/age
function extractJobAge() {
  const url = window.location.hostname;
  let ageText = '';
  let daysOld = null;
  
  try {
    if (url.includes('linkedin.com')) {
      const selectors = [
        '.job-details-jobs-unified-top-card__posted-date',
        '.jobs-unified-top-card__posted-date',
        '.topcard__flavor--metadata'
      ];
      
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          ageText = element.textContent.trim();
          break;
        }
      }
    } else if (url.includes('indeed.com')) {
      const selectors = [
        '.jobsearch-JobMetadataFooter',
        '[class*="jobMetadata"]'
      ];
      
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element && element.textContent.toLowerCase().includes('ago')) {
          ageText = element.textContent.trim();
          break;
        }
      }
    } else if (url.includes('glassdoor.com')) {
      const selectors = [
        '[data-test="job-age"]',
        '[class*="JobAge"]'
      ];
      
      for (const selector of selectors) {
        const element = document.querySelector(selector);
        if (element) {
          ageText = element.textContent.trim();
          break;
        }
      }
    }
    
    // Parse the age text to get days
    if (ageText) {
      daysOld = parseJobAge(ageText);
    }
  } catch (error) {
    console.log('Error extracting job age:', error);
  }
  
  return { ageText, daysOld };
}

// Parse job age text into number of days
function parseJobAge(ageText) {
  const text = ageText.toLowerCase();
  
  // Extract number from text
  const numberMatch = text.match(/\d+/);
  if (!numberMatch) return null;
  
  const number = parseInt(numberMatch[0]);
  
  // Convert to days based on unit
  if (text.includes('minute') || text.includes('min')) {
    return 0;
  } else if (text.includes('hour') || text.includes('hr')) {
    return 0;
  } else if (text.includes('day')) {
    return number;
  } else if (text.includes('week')) {
    return number * 7;
  } else if (text.includes('month')) {
    return number * 30;
  } else if (text.includes('year')) {
    return number * 365;
  }
  
  return null;
}

// Check if company is in ghost job list (with alias support)
function isGhostJobCompany(companyName) {
  if (!companyName) return false;
  
  const normalizedName = companyName.toLowerCase().trim();
  
  // Direct match
  const directMatch = ghostJobCompanies.some(ghostCompany => {
    const normalizedGhost = ghostCompany.toLowerCase().trim();
    return normalizedName.includes(normalizedGhost) || normalizedGhost.includes(normalizedName);
  });
  
  if (directMatch) return true;
  
  // Check aliases
  for (const [parent, aliases] of Object.entries(companyAliases)) {
    const parentMatch = normalizedName.includes(parent.toLowerCase());
    const aliasMatch = aliases.some(alias => 
      normalizedName.includes(alias.toLowerCase()) || alias.toLowerCase().includes(normalizedName)
    );
    
    if (parentMatch || aliasMatch) {
      // Check if parent company is in ghost job list
      if (ghostJobCompanies.some(c => c.toLowerCase() === parent.toLowerCase())) {
        return true;
      }
    }
  }
  
  return false;
}

// Create and show positive job indicator banner
function showPositiveBanner(companyName, jobAge) {
  // Check if banner already exists or if feature is disabled
  if (document.getElementById('ghost-job-positive') || !showPositiveIndicator) {
    return;
  }
  
  // Only show positive indicator for fresh jobs (< 14 days)
  if (!jobAge || jobAge.daysOld === null || jobAge.daysOld > 14) {
    return;
  }
  
  const banner = document.createElement('div');
  banner.id = 'ghost-job-positive';
  banner.className = 'ghost-job-positive';
  
  let freshnessText = '';
  if (jobAge.daysOld === 0) {
    freshnessText = 'Posted today or very recently';
  } else if (jobAge.daysOld === 1) {
    freshnessText = 'Posted yesterday';
  } else if (jobAge.daysOld <= 3) {
    freshnessText = `Posted ${jobAge.daysOld} days ago - Very fresh!`;
  } else if (jobAge.daysOld <= 7) {
    freshnessText = `Posted ${jobAge.daysOld} days ago - Recent posting`;
  } else {
    freshnessText = `Posted ${jobAge.daysOld} days ago`;
  }
  
  banner.innerHTML = `
    <div class="ghost-job-positive-content">
      <div class="ghost-job-positive-icon">👍</div>
      <div class="ghost-job-positive-text">
        <strong>Looking Good!</strong>
        <p><strong>${escapeHtml(companyName)}</strong> is not currently flagged for ghost jobs.</p>
        <p class="ghost-job-positive-freshness">✨ ${freshnessText}</p>
        <p class="ghost-job-positive-advice">
          This is a positive sign, but always verify job details independently and check the company's official careers page.
        </p>
      </div>
      <button class="ghost-job-positive-close" id="ghost-job-positive-close-btn">×</button>
    </div>
  `;
  
  document.body.insertBefore(banner, document.body.firstChild);
  
  // Add close button functionality
  document.getElementById('ghost-job-positive-close-btn').addEventListener('click', () => {
    banner.remove();
  });
  
  // Auto-dismiss after 8 seconds
  setTimeout(() => {
    if (document.getElementById('ghost-job-positive')) {
      banner.style.opacity = '0';
      setTimeout(() => banner.remove(), 300);
    }
  }, 8000);
}

// Create and show warning banner
function showWarningBanner(companyName, jobAge) {
  // Check if banner already exists
  if (document.getElementById('ghost-job-warning')) {
    return;
  }
  
  const banner = document.createElement('div');
  banner.id = 'ghost-job-warning';
  banner.className = 'ghost-job-warning';
  
  // Determine severity based on job age
  let ageWarning = '';
  let severityClass = '';
  
  if (jobAge && jobAge.daysOld !== null) {
    if (jobAge.daysOld > 90) {
      ageWarning = `<div class="ghost-job-age-warning severe">🚨 <strong>CRITICAL:</strong> This job has been posted for ${jobAge.ageText}. Jobs open this long are highly likely to be ghost jobs.</div>`;
      severityClass = 'severe';
    } else if (jobAge.daysOld > 30) {
      ageWarning = `<div class="ghost-job-age-warning high">⚠️ <strong>HIGH RISK:</strong> This job has been posted for ${jobAge.ageText}. Most legitimate jobs fill within 30 days.</div>`;
      severityClass = 'high';
    } else if (jobAge.daysOld > 14) {
      ageWarning = `<div class="ghost-job-age-warning medium">⚡ <strong>CAUTION:</strong> Posted ${jobAge.ageText} ago.</div>`;
      severityClass = 'medium';
    } else if (jobAge.ageText) {
      ageWarning = `<div class="ghost-job-age-warning low">📅 Posted ${jobAge.ageText} ago</div>`;
      severityClass = 'low';
    }
  }
  
  banner.innerHTML = `
    <div class="ghost-job-warning-content ${severityClass}">
      <div class="ghost-job-warning-icon">👻</div>
      <div class="ghost-job-warning-text">
        <strong>Ghost Job Warning</strong>
        <p><strong>${escapeHtml(companyName)}</strong> has been reported for posting ghost jobs - positions they may not intend to fill.</p>
        ${ageWarning}
        <p class="ghost-job-warning-advice">
          <strong>Before applying:</strong> Check if this posting is on the company's official website, verify the posting date, 
          and try contacting the hiring manager directly on LinkedIn.
        </p>
        <div class="ghost-job-warning-actions">
          <a href="https://ghostjobs.io/" target="_blank" class="ghost-job-learn-more">Learn more about ghost jobs</a>
          <button class="ghost-job-report-btn" id="ghost-job-report-btn">Report a Ghost Job</button>
        </div>
      </div>
      <button class="ghost-job-warning-close" id="ghost-job-close-btn">×</button>
    </div>
  `;
  
  document.body.insertBefore(banner, document.body.firstChild);
  
  // Add close button functionality
  document.getElementById('ghost-job-close-btn').addEventListener('click', () => {
    banner.remove();
  });
  
  // Add report button functionality
  document.getElementById('ghost-job-report-btn').addEventListener('click', () => {
    showReportDialog(companyName);
  });
  
  // Track that we showed a warning
  chrome.runtime.sendMessage({
    action: 'warningShown',
    company: companyName,
    url: window.location.href,
    jobAge: jobAge ? jobAge.daysOld : null
  });
}

// Show report dialog for users to report ghost jobs
function showReportDialog(companyName) {
  const existingDialog = document.getElementById('ghost-job-report-dialog');
  if (existingDialog) {
    existingDialog.remove();
  }
  
  const dialog = document.createElement('div');
  dialog.id = 'ghost-job-report-dialog';
  dialog.className = 'ghost-job-report-dialog';
  
  dialog.innerHTML = `
    <div class="ghost-job-report-content">
      <h3>Report Ghost Job</h3>
      <p>Help other job seekers by reporting ghost jobs:</p>
      <input type="text" id="report-company-name" value="${escapeHtml(companyName)}" placeholder="Company name">
      <textarea id="report-reason" placeholder="Reason (optional): e.g., Never heard back, position reposted multiple times, etc."></textarea>
      <div class="ghost-job-report-buttons">
        <button id="submit-report-btn" class="ghost-job-btn-primary">Submit Report</button>
        <button id="cancel-report-btn" class="ghost-job-btn-secondary">Cancel</button>
      </div>
      <p class="ghost-job-report-note">Reports help improve the database for everyone</p>
    </div>
  `;
  
  document.body.appendChild(dialog);
  
  document.getElementById('submit-report-btn').addEventListener('click', () => {
    const reportedCompany = document.getElementById('report-company-name').value.trim();
    const reason = document.getElementById('report-reason').value.trim();
    
    if (reportedCompany) {
      chrome.runtime.sendMessage({
        action: 'reportCompany',
        company: reportedCompany,
        reason: reason
      }, (response) => {
        if (response && response.success) {
          alert('Thank you for your report! It will help protect other job seekers.');
          dialog.remove();
        }
      });
    }
  });
  
  document.getElementById('cancel-report-btn').addEventListener('click', () => {
    dialog.remove();
  });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Main function to check for ghost jobs
function checkForGhostJobs() {
  // Wait a bit for the page to load
  setTimeout(() => {
    const companyName = extractCompanyName();
    const jobAge = extractJobAge();
    
    if (companyName) {
      console.log('Detected company:', companyName);
      if (jobAge.ageText) {
        console.log('Job age:', jobAge.ageText, `(${jobAge.daysOld} days)`);
      }
      
      if (isGhostJobCompany(companyName)) {
        console.log('Ghost job company detected:', companyName);
        showWarningBanner(companyName, jobAge);
      } else {
        console.log('Company not flagged for ghost jobs:', companyName);
        // Show positive indicator for fresh jobs from non-flagged companies
        showPositiveBanner(companyName, jobAge);
      }
    } else {
      console.log('Could not extract company name');
      // Try again in a few seconds as some sites load slowly
      setTimeout(checkForGhostJobs, 2000);
    }
  }, 1000);
}

// Listen for URL changes (for single-page applications)
let lastUrl = window.location.href;
new MutationObserver(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    // Remove old warning
    const oldWarning = document.getElementById('ghost-job-warning');
    if (oldWarning) {
      oldWarning.remove();
    }
    // Remove old positive indicator
    const oldPositive = document.getElementById('ghost-job-positive');
    if (oldPositive) {
      oldPositive.remove();
    }
    // Remove old dialog if exists
    const oldDialog = document.getElementById('ghost-job-report-dialog');
    if (oldDialog) {
      oldDialog.remove();
    }
    // Check for ghost jobs on the new page
    checkForGhostJobs();
  }
}).observe(document.body, { childList: true, subtree: true });

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateCompanyList') {
    ghostJobCompanies = request.companies;
    companyAliases = request.aliases || {};
    console.log('Updated ghost job companies list:', ghostJobCompanies.length);
    checkForGhostJobs();
  } else if (request.action === 'updatePositiveIndicatorSetting') {
    showPositiveIndicator = request.enabled;
    console.log('Positive indicator setting updated:', showPositiveIndicator);
  }
});
