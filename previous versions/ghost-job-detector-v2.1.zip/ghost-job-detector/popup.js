// Ghost Job Detector - Popup Script

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  loadCompanyList();
  loadSettings();
  
  // Add company button
  document.getElementById('add-company-btn').addEventListener('click', addCompany);
  
  // Update list button
  document.getElementById('update-list-btn').addEventListener('click', updateList);
  
  // Export history button
  document.getElementById('export-history-btn').addEventListener('click', exportHistory);
  
  // Dark mode toggle
  document.getElementById('dark-mode-toggle').addEventListener('change', (e) => {
    toggleDarkMode(e.target.checked);
  });
  
  // Auto-update toggle
  document.getElementById('auto-update-toggle').addEventListener('change', (e) => {
    toggleAutoUpdate(e.target.checked);
  });
  
  // Positive indicator toggle
  document.getElementById('positive-indicator-toggle').addEventListener('change', (e) => {
    togglePositiveIndicator(e.target.checked);
  });
  
  // Allow Enter key to add company
  document.getElementById('company-input').addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      addCompany();
    }
  });
});

// Load settings
function loadSettings() {
  chrome.storage.local.get(['darkMode', 'autoUpdate', 'showPositiveIndicator'], (result) => {
    const darkMode = result.darkMode || false;
    const autoUpdate = result.autoUpdate !== false; // Default to true
    const showPositiveIndicator = result.showPositiveIndicator !== false; // Default to true
    
    document.getElementById('dark-mode-toggle').checked = darkMode;
    document.getElementById('auto-update-toggle').checked = autoUpdate;
    document.getElementById('positive-indicator-toggle').checked = showPositiveIndicator;
    
    if (darkMode) {
      document.body.classList.add('dark-mode');
    }
  });
}

// Load statistics
function loadStats() {
  chrome.storage.local.get(['ghostJobCompanies', 'warningCount', 'lastUpdated'], (result) => {
    const companyCount = result.ghostJobCompanies ? result.ghostJobCompanies.length : 0;
    const warningCount = result.warningCount || 0;
    const lastUpdated = result.lastUpdated || 0;
    
    document.getElementById('company-count').textContent = companyCount;
    document.getElementById('warning-count').textContent = warningCount;
    
    if (lastUpdated) {
      const date = new Date(lastUpdated);
      const now = new Date();
      const diffInHours = Math.floor((now - date) / (1000 * 60 * 60));
      
      if (diffInHours < 1) {
        document.getElementById('last-updated').textContent = 'Just now';
      } else if (diffInHours < 24) {
        document.getElementById('last-updated').textContent = `${diffInHours}h ago`;
      } else {
        const diffInDays = Math.floor(diffInHours / 24);
        document.getElementById('last-updated').textContent = `${diffInDays}d ago`;
      }
    } else {
      document.getElementById('last-updated').textContent = 'Never';
    }
  });
}

// Load company list
function loadCompanyList() {
  chrome.storage.local.get(['ghostJobCompanies'], (result) => {
    const companies = result.ghostJobCompanies || [];
    const listContainer = document.getElementById('company-list-items');
    document.getElementById('list-count').textContent = companies.length;
    
    if (companies.length === 0) {
      listContainer.innerHTML = '<div style="opacity: 0.7; font-size: 12px;">No companies tracked yet</div>';
      return;
    }
    
    // Sort companies alphabetically
    companies.sort((a, b) => a.localeCompare(b));
    
    listContainer.innerHTML = companies.map(company => `
      <div class="company-item">
        <span>${escapeHtml(company)}</span>
        <button class="remove-btn" data-company="${escapeHtml(company)}">Remove</button>
      </div>
    `).join('');
    
    // Add event listeners to remove buttons
    document.querySelectorAll('.remove-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        const company = e.target.getAttribute('data-company');
        removeCompany(company);
      });
    });
  });
}

// Add a company to the list
function addCompany() {
  const input = document.getElementById('company-input');
  const companyName = input.value.trim();
  
  if (!companyName) {
    showMessage('Please enter a company name', 'error');
    return;
  }
  
  chrome.storage.local.get(['ghostJobCompanies'], (result) => {
    const companies = result.ghostJobCompanies || [];
    
    if (companies.some(c => c.toLowerCase() === companyName.toLowerCase())) {
      showMessage('Company already in the list', 'error');
      return;
    }
    
    companies.push(companyName);
    
    chrome.storage.local.set({ ghostJobCompanies: companies }, () => {
      showMessage('Company added successfully', 'success');
      input.value = '';
      loadStats();
      loadCompanyList();
      
      // Notify background script
      chrome.runtime.sendMessage({
        action: 'addCompany',
        company: companyName
      });
    });
  });
}

// Remove a company from the list
function removeCompany(companyName) {
  chrome.storage.local.get(['ghostJobCompanies'], (result) => {
    let companies = result.ghostJobCompanies || [];
    companies = companies.filter(c => c !== companyName);
    
    chrome.storage.local.set({ ghostJobCompanies: companies }, () => {
      showMessage('Company removed', 'success');
      loadStats();
      loadCompanyList();
      
      // Notify background script
      chrome.runtime.sendMessage({
        action: 'removeCompany',
        company: companyName
      });
    });
  });
}

// Update the ghost job list
function updateList() {
  const btn = document.getElementById('update-list-btn');
  const originalText = btn.textContent;
  btn.textContent = '🔄 Updating...';
  btn.disabled = true;
  
  chrome.runtime.sendMessage({ action: 'updateGhostJobList' }, (response) => {
    setTimeout(() => {
      loadStats();
      loadCompanyList();
      if (response && response.success) {
        showMessage(`List updated! ${response.count} companies tracked.`, 'success');
      } else {
        showMessage('List updated successfully', 'success');
      }
      btn.textContent = originalText;
      btn.disabled = false;
    }, 500);
  });
}

// Export warning history
function exportHistory() {
  chrome.runtime.sendMessage({ action: 'exportHistory' }, (response) => {
    if (response && response.success) {
      const data = response.data;
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `ghost-job-history-${new Date().toISOString().split('T')[0]}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      
      showMessage('History exported successfully', 'success');
    } else {
      showMessage('No history to export', 'error');
    }
  });
}

// Toggle dark mode
function toggleDarkMode(enabled) {
  if (enabled) {
    document.body.classList.add('dark-mode');
  } else {
    document.body.classList.remove('dark-mode');
  }
  
  chrome.runtime.sendMessage({
    action: 'toggleDarkMode',
    enabled: enabled
  });
}

// Toggle auto-update
function toggleAutoUpdate(enabled) {
  chrome.runtime.sendMessage({
    action: 'toggleAutoUpdate',
    enabled: enabled
  }, () => {
    showMessage(`Auto-update ${enabled ? 'enabled' : 'disabled'}`, 'success');
  });
}

// Toggle positive indicator
function togglePositiveIndicator(enabled) {
  chrome.storage.local.set({ showPositiveIndicator: enabled }, () => {
    showMessage(`Positive indicators ${enabled ? 'enabled' : 'disabled'}`, 'success');
    
    // Notify all content scripts
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            action: 'updatePositiveIndicatorSetting',
            enabled: enabled
          }).catch(() => {
            // Ignore errors for tabs where content script isn't loaded
          });
        }
      });
    });
  });
}

// Show a message to the user
function showMessage(text, type) {
  const messageEl = document.getElementById('message');
  messageEl.textContent = text;
  messageEl.className = `message ${type}`;
  
  setTimeout(() => {
    messageEl.className = 'message';
  }, 3000);
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}
