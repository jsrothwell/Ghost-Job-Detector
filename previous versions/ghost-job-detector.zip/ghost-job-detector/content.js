// Ghost Job Detector - Content Script

// Known ghost job companies (starter list - can be updated from GhostJobs.io)
let ghostJobCompanies = [];

// Load the ghost job companies list from storage
chrome.storage.local.get(['ghostJobCompanies', 'lastUpdated'], (result) => {
  if (result.ghostJobCompanies) {
    ghostJobCompanies = result.ghostJobCompanies;
    console.log('Loaded ghost job companies:', ghostJobCompanies.length);
  }
  
  // Check if we need to update the list (update every 24 hours)
  const lastUpdated = result.lastUpdated || 0;
  const dayInMs = 24 * 60 * 60 * 1000;
  
  if (Date.now() - lastUpdated > dayInMs) {
    chrome.runtime.sendMessage({ action: 'updateGhostJobList' });
  }
  
  // Start checking for ghost jobs
  checkForGhostJobs();
});

// Extract company name from different job sites
function extractCompanyName() {
  const url = window.location.hostname;
  let companyName = '';
  
  if (url.includes('linkedin.com')) {
    // LinkedIn selectors
    const selectors = [
      '.job-details-jobs-unified-top-card__company-name a',
      '.job-details-jobs-unified-top-card__company-name',
      '.jobs-unified-top-card__company-name a',
      '.jobs-unified-top-card__company-name',
      '.topcard__org-name-link',
      '.topcard__flavor--black-link'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('indeed.com')) {
    // Indeed selectors
    const selectors = [
      '[data-company-name="true"]',
      '.jobsearch-CompanyInfoContainer a',
      '.jobsearch-InlineCompanyRating-companyHeader a',
      '[class*="companyName"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('glassdoor.com')) {
    // Glassdoor selectors
    const selectors = [
      '[data-test="employer-name"]',
      '.employerName',
      '[class*="EmployerProfile_employerName"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('ziprecruiter.com')) {
    // ZipRecruiter selectors
    const selectors = [
      '[class*="CompanyName"]',
      'a.company_name'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element) {
        companyName = element.textContent.trim();
        break;
      }
    }
  } else if (url.includes('wellfound.com')) {
    // Wellfound (AngelList) selectors
    const selectors = [
      '[class*="company"]',
      'a[href*="/company/"]'
    ];
    
    for (const selector of selectors) {
      const element = document.querySelector(selector);
      if (element && element.href && element.href.includes('/company/')) {
        companyName = element.textContent.trim();
        break;
      }
    }
  }
  
  return companyName;
}

// Check if company is in ghost job list
function isGhostJobCompany(companyName) {
  if (!companyName) return false;
  
  const normalizedName = companyName.toLowerCase().trim();
  
  return ghostJobCompanies.some(ghostCompany => {
    const normalizedGhost = ghostCompany.toLowerCase().trim();
    return normalizedName.includes(normalizedGhost) || normalizedGhost.includes(normalizedName);
  });
}

// Create and show warning banner
function showWarningBanner(companyName) {
  // Check if banner already exists
  if (document.getElementById('ghost-job-warning')) {
    return;
  }
  
  const banner = document.createElement('div');
  banner.id = 'ghost-job-warning';
  banner.className = 'ghost-job-warning';
  
  banner.innerHTML = `
    <div class="ghost-job-warning-content">
      <div class="ghost-job-warning-icon">⚠️</div>
      <div class="ghost-job-warning-text">
        <strong>Ghost Job Warning</strong>
        <p><strong>${escapeHtml(companyName)}</strong> has been reported for posting ghost jobs - positions they may not intend to fill.</p>
        <p class="ghost-job-warning-advice">
          Consider: Check if this posting is on the company's official website, verify the posting date, 
          and try contacting the hiring manager directly on LinkedIn before investing time in this application.
        </p>
        <a href="https://ghostjobs.io/" target="_blank" class="ghost-job-learn-more">Learn more about ghost jobs</a>
      </div>
      <button class="ghost-job-warning-close" id="ghost-job-close-btn">×</button>
    </div>
  `;
  
  document.body.insertBefore(banner, document.body.firstChild);
  
  // Add close button functionality
  document.getElementById('ghost-job-close-btn').addEventListener('click', () => {
    banner.remove();
  });
  
  // Track that we showed a warning
  chrome.runtime.sendMessage({
    action: 'warningShown',
    company: companyName,
    url: window.location.href
  });
}

// Escape HTML to prevent XSS
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Main function to check for ghost jobs
function checkForGhostJobs() {
  // Wait a bit for the page to load
  setTimeout(() => {
    const companyName = extractCompanyName();
    
    if (companyName) {
      console.log('Detected company:', companyName);
      
      if (isGhostJobCompany(companyName)) {
        console.log('Ghost job company detected:', companyName);
        showWarningBanner(companyName);
      }
    } else {
      console.log('Could not extract company name');
      // Try again in a few seconds as some sites load slowly
      setTimeout(checkForGhostJobs, 2000);
    }
  }, 1000);
}

// Listen for URL changes (for single-page applications)
let lastUrl = window.location.href;
new MutationObserver(() => {
  const currentUrl = window.location.href;
  if (currentUrl !== lastUrl) {
    lastUrl = currentUrl;
    // Remove old warning
    const oldWarning = document.getElementById('ghost-job-warning');
    if (oldWarning) {
      oldWarning.remove();
    }
    // Check for ghost jobs on the new page
    checkForGhostJobs();
  }
}).observe(document.body, { childList: true, subtree: true });

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateCompanyList') {
    ghostJobCompanies = request.companies;
    console.log('Updated ghost job companies list:', ghostJobCompanies.length);
    checkForGhostJobs();
  }
});
