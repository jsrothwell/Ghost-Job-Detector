// Ghost Job Detector - Background Service Worker

// Default list of companies known to post ghost jobs
// This is a starter list based on Reddit community reports
const DEFAULT_GHOST_COMPANIES = [
  'Accenture',
  'CVS Health',
  'Dice',
  'Crossover',
  'Revature',
  'TEKsystems',
  'Robert Half',
  'Insight Global',
  'Apex Systems',
  'ManpowerGroup',
  'Kelly Services',
  'Randstad',
  'Aerotek'
];

// Initialize the extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Ghost Job Detector installed');
    initializeGhostJobList();
  } else if (details.reason === 'update') {
    console.log('Ghost Job Detector updated');
    updateGhostJobList();
  }
});

// Initialize the ghost job list with default companies
function initializeGhostJobList() {
  chrome.storage.local.set({
    ghostJobCompanies: DEFAULT_GHOST_COMPANIES,
    lastUpdated: Date.now(),
    warningCount: 0
  }, () => {
    console.log('Ghost job list initialized with default companies');
  });
}

// Update the ghost job list (placeholder for future API integration)
async function updateGhostJobList() {
  try {
    // For now, we'll use the default list
    // In the future, this could scrape GhostJobs.io or use an API if available
    
    // Placeholder for future implementation:
    // const response = await fetch('https://ghostjobs.io/api/companies');
    // const data = await response.json();
    // const companies = data.companies;
    
    const companies = DEFAULT_GHOST_COMPANIES;
    
    chrome.storage.local.set({
      ghostJobCompanies: companies,
      lastUpdated: Date.now()
    }, () => {
      console.log('Ghost job list updated:', companies.length, 'companies');
      
      // Notify all content scripts about the update
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              action: 'updateCompanyList',
              companies: companies
            }).catch(() => {
              // Ignore errors for tabs where content script isn't loaded
            });
          }
        });
      });
    });
  } catch (error) {
    console.error('Error updating ghost job list:', error);
  }
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateGhostJobList') {
    updateGhostJobList();
  } else if (request.action === 'warningShown') {
    // Track warnings shown
    chrome.storage.local.get(['warningCount'], (result) => {
      const count = (result.warningCount || 0) + 1;
      chrome.storage.local.set({ warningCount: count });
      console.log('Warning shown for:', request.company, '(Total warnings:', count + ')');
    });
  } else if (request.action === 'addCompany') {
    // Allow users to add companies to the list
    chrome.storage.local.get(['ghostJobCompanies'], (result) => {
      const companies = result.ghostJobCompanies || [];
      if (!companies.includes(request.company)) {
        companies.push(request.company);
        chrome.storage.local.set({ ghostJobCompanies: companies });
        console.log('Added company to ghost job list:', request.company);
      }
    });
  } else if (request.action === 'removeCompany') {
    // Allow users to remove companies from the list
    chrome.storage.local.get(['ghostJobCompanies'], (result) => {
      let companies = result.ghostJobCompanies || [];
      companies = companies.filter(c => c !== request.company);
      chrome.storage.local.set({ ghostJobCompanies: companies });
      console.log('Removed company from ghost job list:', request.company);
    });
  }
});

// Update the list periodically (every 24 hours)
chrome.alarms.create('updateGhostJobList', { periodInMinutes: 1440 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateGhostJobList') {
    updateGhostJobList();
  }
});
