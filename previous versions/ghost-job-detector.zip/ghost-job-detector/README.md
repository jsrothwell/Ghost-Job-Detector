# Ghost Job Detector - Chrome Extension

A Chrome extension that warns you when viewing job postings from companies known to post "ghost jobs" - positions they may not actually intend to fill.

## Features

- 🚨 **Automatic Detection**: Warns you when viewing job postings from companies with a history of ghost jobs
- 🔍 **Multi-Platform Support**: Works on LinkedIn, Indeed, Glassdoor, ZipRecruiter, and Wellfound
- 📊 **Statistics Tracking**: Monitor how many warnings you've received
- ➕ **Custom Company List**: Add or remove companies from your tracking list
- 🎨 **Clean Interface**: Non-intrusive warning banner with helpful advice
- 📱 **Responsive Design**: Works on all screen sizes

## What are Ghost Jobs?

Ghost jobs are job postings for positions that companies have no real intention of filling immediately (or at all). Companies post them for various reasons:
- Building talent pipelines for future openings
- Creating the appearance of company growth
- Meeting federal posting requirements
- Pressuring current employees
- Collecting market data on salaries and candidates

Research shows that **20-40% of job postings** may be ghost jobs, wasting countless hours for job seekers.

## Installation

### Method 1: Load as Unpacked Extension (Recommended for Development)

1. Download or clone this repository
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top right
4. Click "Load unpacked"
5. Select the `ghost-job-detector` folder
6. The extension should now appear in your extensions list

### Method 2: Chrome Web Store (Future)

The extension will be available on the Chrome Web Store once published.

## How to Use

1. **Automatic Warnings**: Simply browse job postings on supported sites. If you visit a posting from a company in the ghost job database, you'll see a warning banner at the top of the page.

2. **Add Companies**: Click the extension icon in your toolbar to open the popup, where you can:
   - View statistics (companies tracked, warnings shown)
   - Add new companies to your tracking list
   - Remove companies from the list
   - Update the database

3. **Close Warnings**: Click the × button on any warning banner to dismiss it.

## Supported Job Sites

- LinkedIn Jobs
- Indeed
- Glassdoor
- ZipRecruiter
- Wellfound (formerly AngelList Talent)

## Default Tracked Companies

The extension comes with a starter list of companies frequently reported for ghost jobs:
- Accenture
- CVS Health
- Dice
- Crossover
- Revature
- TEKsystems
- Robert Half
- Insight Global
- Apex Systems
- ManpowerGroup
- Kelly Services
- Randstad
- Aerotek

**Note**: This list is based on community reports from Reddit (r/jobs, r/antiwork, r/JobSearchHacks) and the GhostJobs.io database. Being on this list doesn't mean a company *never* has real jobs, just that they've been reported for ghost job practices.

## Data Source

This extension references data from [GhostJobs.io](https://ghostjobs.io/), a community-driven database that monitors job boards and flags suspicious listings.

## Privacy

- **No Data Collection**: This extension does NOT collect, store, or transmit any personal data
- **Local Storage Only**: All data is stored locally on your device
- **No Tracking**: No analytics or tracking of any kind
- **Open Source**: The code is fully transparent and auditable

## Tips for Avoiding Ghost Jobs

1. **Check posting dates**: Jobs open for 30+ days are often ghosts
2. **Cross-reference**: Verify the job exists on the company's official careers page
3. **Contact directly**: Reach out to the hiring manager on LinkedIn
4. **Look for specifics**: Vague job descriptions are a red flag
5. **Check reviews**: Search Glassdoor and Reddit for company reputation

## Contributing

Contributions are welcome! To add companies to the database or improve the extension:

1. Fork this repository
2. Make your changes
3. Submit a pull request

### Adding Companies

To suggest companies for the default list, please provide:
- Company name
- Evidence of ghost job practices (Reddit posts, personal experiences, etc.)
- Any additional context

## Future Enhancements

- [ ] Integration with GhostJobs.io API (when available)
- [ ] More sophisticated company matching (handle subsidiaries, alternate names)
- [ ] Job posting age detection
- [ ] User rating system for companies
- [ ] Export warning history
- [ ] Dark mode
- [ ] Additional job site support

## Disclaimer

This extension is provided "as is" for informational purposes. Being flagged as a potential ghost job does not guarantee a posting is fake, and legitimate companies may occasionally have jobs flagged. Always use your own judgment when applying to positions.

## License

MIT License - feel free to use, modify, and distribute this extension.

## Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Check the [GhostJobs.io](https://ghostjobs.io/) website for more information on ghost jobs

## Acknowledgments

- Data sourced from [GhostJobs.io](https://ghostjobs.io/)
- Community reports from Reddit communities: r/jobs, r/antiwork, r/JobSearchHacks
- Built to help job seekers save time and avoid frustration

---

**Remember**: Focus your energy on recent postings, verify directly with companies, and don't let ghost jobs discourage you. Real opportunities are out there! 👻🚫
