// Ghost Job Detector - Background Service Worker

// Default list of companies known to post ghost jobs
// This is a starter list based on Reddit community reports
const DEFAULT_GHOST_COMPANIES = [
  'Accenture',
  'CVS Health',
  'Dice',
  'Crossover',
  'Revature',
  'TEKsystems',
  'Robert Half',
  'Insight Global',
  'Apex Systems',
  'ManpowerGroup',
  'Kelly Services',
  'Randstad',
  'Aerotek'
];

// Company aliases and subsidiaries for better matching
const COMPANY_ALIASES = {
  'Accenture': ['Accenture Federal Services', 'Accenture Technology', 'Avanade'],
  'CVS Health': ['CVS', 'CVS Pharmacy', 'Aetna', 'CVS Caremark'],
  'Robert Half': ['Robert Half Technology', 'Robert Half Finance', 'Protiviti'],
  'ManpowerGroup': ['Manpower', 'Experis', 'Talent Solutions'],
  'Kelly Services': ['Kelly', 'Kelly IT', 'Kelly Engineering'],
  'Randstad': ['Randstad Technologies', 'Randstad Digital', 'Randstad Engineering']
};

// Initialize the extension
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('Ghost Job Detector installed');
    initializeGhostJobList();
  } else if (details.reason === 'update') {
    console.log('Ghost Job Detector updated');
    updateGhostJobList();
  }
});

// Initialize the ghost job list with default companies
function initializeGhostJobList() {
  chrome.storage.local.set({
    ghostJobCompanies: DEFAULT_GHOST_COMPANIES,
    companyAliases: COMPANY_ALIASES,
    lastUpdated: Date.now(),
    warningCount: 0,
    userReports: [],
    darkMode: false,
    autoUpdate: true,
    showPositiveIndicator: true
  }, () => {
    console.log('Ghost job list initialized with default companies');
    // Trigger first update from GhostJobs.io
    updateGhostJobList();
  });
}

// Scrape GhostJobs.io for reported companies
async function scrapeGhostJobsIO() {
  try {
    console.log('Attempting to fetch data from GhostJobs.io...');
    
    // Note: This is a simplified scraping approach
    // GhostJobs.io doesn't have a public API, so we'll attempt to parse their website
    const response = await fetch('https://ghostjobs.io/', {
      method: 'GET',
      headers: {
        'Accept': 'text/html',
      }
    });
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }
    
    const html = await response.text();
    
    // Parse company names from the HTML
    // This is a basic implementation - the actual structure may vary
    const companyPattern = /<[^>]*class="[^"]*company[^"]*"[^>]*>([^<]+)<\/[^>]*>/gi;
    const matches = html.matchAll(companyPattern);
    const scrapedCompanies = new Set();
    
    for (const match of matches) {
      const companyName = match[1].trim();
      if (companyName && companyName.length > 2 && companyName.length < 100) {
        scrapedCompanies.add(companyName);
      }
    }
    
    console.log('Scraped companies from GhostJobs.io:', scrapedCompanies.size);
    return Array.from(scrapedCompanies);
  } catch (error) {
    console.error('Error scraping GhostJobs.io:', error);
    return [];
  }
}

// Update the ghost job list from multiple sources
async function updateGhostJobList() {
  try {
    console.log('Updating ghost job list...');
    
    // Get current user-added companies
    const storage = await chrome.storage.local.get(['ghostJobCompanies', 'userReports', 'autoUpdate']);
    const currentCompanies = storage.ghostJobCompanies || [];
    const userReports = storage.userReports || [];
    const autoUpdate = storage.autoUpdate !== false;
    
    let updatedCompanies = [...DEFAULT_GHOST_COMPANIES];
    
    // Add user-reported companies
    const reportedCompanies = userReports
      .filter(report => report.votes >= 2) // Require at least 2 reports
      .map(report => report.company);
    updatedCompanies = [...new Set([...updatedCompanies, ...reportedCompanies])];
    
    // Try to fetch from GhostJobs.io if auto-update is enabled
    if (autoUpdate) {
      try {
        const scrapedCompanies = await scrapeGhostJobsIO();
        if (scrapedCompanies.length > 0) {
          updatedCompanies = [...new Set([...updatedCompanies, ...scrapedCompanies])];
          console.log('Successfully updated from GhostJobs.io');
        }
      } catch (error) {
        console.log('Could not fetch from GhostJobs.io, using cached data');
      }
    }
    
    // Preserve any manually added companies
    const manuallyAdded = currentCompanies.filter(company => 
      !DEFAULT_GHOST_COMPANIES.includes(company)
    );
    updatedCompanies = [...new Set([...updatedCompanies, ...manuallyAdded])];
    
    // Sort alphabetically
    updatedCompanies.sort((a, b) => a.localeCompare(b));
    
    await chrome.storage.local.set({
      ghostJobCompanies: updatedCompanies,
      companyAliases: COMPANY_ALIASES,
      lastUpdated: Date.now()
    });
    
    console.log('Ghost job list updated:', updatedCompanies.length, 'companies');
    
    // Notify all content scripts about the update
    const tabs = await chrome.tabs.query({});
    tabs.forEach(tab => {
      if (tab.id) {
        chrome.tabs.sendMessage(tab.id, {
          action: 'updateCompanyList',
          companies: updatedCompanies,
          aliases: COMPANY_ALIASES
        }).catch(() => {
          // Ignore errors for tabs where content script isn't loaded
        });
      }
    });
    
    return updatedCompanies;
  } catch (error) {
    console.error('Error updating ghost job list:', error);
    return DEFAULT_GHOST_COMPANIES;
  }
}

// Listen for messages from content scripts
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'updateGhostJobList') {
    updateGhostJobList().then(companies => {
      sendResponse({ success: true, count: companies.length });
    });
    return true; // Keep channel open for async response
  } else if (request.action === 'warningShown') {
    // Track warnings shown
    chrome.storage.local.get(['warningCount', 'warningHistory'], (result) => {
      const count = (result.warningCount || 0) + 1;
      const history = result.warningHistory || [];
      
      history.push({
        company: request.company,
        url: request.url,
        timestamp: Date.now(),
        jobAge: request.jobAge
      });
      
      // Keep only last 100 warnings
      const recentHistory = history.slice(-100);
      
      chrome.storage.local.set({ 
        warningCount: count,
        warningHistory: recentHistory
      });
      console.log('Warning shown for:', request.company, '(Total warnings:', count + ')');
    });
  } else if (request.action === 'addCompany') {
    // Allow users to add companies to the list
    chrome.storage.local.get(['ghostJobCompanies'], (result) => {
      const companies = result.ghostJobCompanies || [];
      if (!companies.includes(request.company)) {
        companies.push(request.company);
        companies.sort((a, b) => a.localeCompare(b));
        chrome.storage.local.set({ ghostJobCompanies: companies });
        console.log('Added company to ghost job list:', request.company);
        sendResponse({ success: true });
      } else {
        sendResponse({ success: false, message: 'Company already exists' });
      }
    });
    return true;
  } else if (request.action === 'removeCompany') {
    // Allow users to remove companies from the list
    chrome.storage.local.get(['ghostJobCompanies'], (result) => {
      let companies = result.ghostJobCompanies || [];
      companies = companies.filter(c => c !== request.company);
      chrome.storage.local.set({ ghostJobCompanies: companies });
      console.log('Removed company from ghost job list:', request.company);
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'reportCompany') {
    // User report system
    chrome.storage.local.get(['userReports'], (result) => {
      const reports = result.userReports || [];
      const existingReport = reports.find(r => r.company === request.company);
      
      if (existingReport) {
        existingReport.votes += 1;
        existingReport.lastReported = Date.now();
      } else {
        reports.push({
          company: request.company,
          votes: 1,
          firstReported: Date.now(),
          lastReported: Date.now(),
          reason: request.reason
        });
      }
      
      chrome.storage.local.set({ userReports: reports });
      console.log('Company reported:', request.company);
      sendResponse({ success: true });
    });
    return true;
  } else if (request.action === 'exportHistory') {
    // Export warning history
    chrome.storage.local.get(['warningHistory', 'ghostJobCompanies'], (result) => {
      const data = {
        exportDate: new Date().toISOString(),
        warningHistory: result.warningHistory || [],
        trackedCompanies: result.ghostJobCompanies || []
      };
      sendResponse({ success: true, data: data });
    });
    return true;
  } else if (request.action === 'toggleDarkMode') {
    chrome.storage.local.set({ darkMode: request.enabled });
    sendResponse({ success: true });
    return true;
  } else if (request.action === 'toggleAutoUpdate') {
    chrome.storage.local.set({ autoUpdate: request.enabled });
    sendResponse({ success: true });
    return true;
  }
});

// Update the list periodically (every 24 hours)
chrome.alarms.create('updateGhostJobList', { periodInMinutes: 1440 });

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'updateGhostJobList') {
    updateGhostJobList();
  }
});
