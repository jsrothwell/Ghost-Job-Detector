# Ghost Job Detector - Chrome Extension

A powerful Chrome extension that warns you when viewing job postings from companies known to post "ghost jobs" - positions they may not actually intend to fill.

## 🆕 What's New in v2.0

- **Job Age Detection**: Automatically detects how long jobs have been posted with severity warnings
- **GhostJobs.io Integration**: Auto-scrapes and updates from GhostJobs.io database
- **Community Reporting**: Report ghost jobs directly and help others
- **Company Aliases**: Better matching with support for subsidiaries and alternate names
- **Dark Mode**: Eye-friendly dark theme option
- **Export History**: Download your complete warning history
- **Enhanced UI**: Color-coded severity warnings with visual indicators

## ✨ Features

### 🚨 Automatic Detection
- Monitors LinkedIn, Indeed, Glassdoor, ZipRecruiter, and Wellfound
- Shows warning banner when viewing jobs from companies known for ghost jobs
- Extracts company names automatically from job postings
- **Supports company aliases and subsidiaries** for better matching (e.g., "Accenture Technology" → "Accenture")

### 📅 Job Age Detection
- **Automatically detects how long a job has been posted**
- **Color-coded severity warnings:**
  - 🚨 **CRITICAL** (90+ days): Highly likely to be a ghost job, pulsing animation
  - ⚠️ **HIGH RISK** (30-90 days): Most legitimate jobs fill within 30 days
  - ⚡ **CAUTION** (14-30 days): Moderately old posting
  - 📅 **RECENT** (<14 days): Freshly posted

### ⚠️ Enhanced Warning Banner
- Eye-catching red gradient banner at the top of the page
- Shows company name, warning message, and job age
- Severity-based visual indicators with colored accents
- Practical advice on verifying if the job is real
- **Report button** to flag ghost jobs you encounter
- Dismissible with a close button

### 🔄 Auto-Update from GhostJobs.io
- **Automatically scrapes GhostJobs.io** for reported companies
- Updates database every 24 hours
- Can be toggled on/off in settings
- Merges community data with your custom list

### 👥 Community Reporting System
- **Report ghost jobs** directly from job postings
- User reports are tracked and aggregated
- Companies with 2+ reports are automatically added to database
- Help protect other job seekers with your experience

### 🎨 Management Interface
- **Dark mode support** for comfortable viewing
- Dashboard showing statistics:
  - Companies tracked
  - Warnings shown
  - Last database update
- Add/remove companies from your tracking list
- Toggle auto-update on/off
- Export warning history as JSON
- Clean, modern UI with gradient design

### 📊 Enhanced Tracking
- Complete warning history with timestamps
- Job age data for each warning
- Export functionality for analysis
- Company alias mappings

## What are Ghost Jobs?

Ghost jobs are job postings for positions that companies have no real intention of filling immediately (or at all). Companies post them for various reasons:
- Building talent pipelines for future openings
- Creating the appearance of company growth
- Meeting federal posting requirements
- Pressuring current employees
- Collecting market data on salaries and candidates

Research shows that **20-40% of job postings** may be ghost jobs, wasting countless hours for job seekers.

## Installation

### Method 1: Load as Unpacked Extension (Recommended)

1. Download and extract `ghost-job-detector.zip`
2. Open Chrome and navigate to `chrome://extensions/`
3. Enable "Developer mode" using the toggle in the top right
4. Click "Load unpacked"
5. Select the extracted `ghost-job-detector` folder
6. The extension should now appear in your extensions list

### Method 2: Chrome Web Store (Coming Soon)

The extension will be available on the Chrome Web Store once published.

## How to Use

### 1. Automatic Warnings
Simply browse job postings on supported sites. If you visit a posting from a company in the ghost job database, you'll see:
- A warning banner at the top with company name
- Job posting age (if detectable)
- Severity indicator based on how long it's been posted
- Advice on how to verify the job

### 2. Report Ghost Jobs
Encountered a ghost job? Help others by reporting it:
1. Click the "Report a Ghost Job" button on the warning banner
2. Confirm/edit the company name
3. Optionally add details about why you think it's a ghost job
4. Submit your report

Reports are aggregated. Companies with 2+ reports are automatically added to the community database.

### 3. Manage Settings
Click the extension icon (👻) in your toolbar to:
- **View Statistics**: See how many companies are tracked and warnings shown
- **Add Companies**: Manually add companies to your list
- **Remove Companies**: Remove companies you don't want to track
- **Toggle Dark Mode**: Switch to a darker theme
- **Toggle Auto-Update**: Enable/disable automatic database updates
- **Export History**: Download your warning history as JSON

### 4. Update Database
The database auto-updates every 24 hours when auto-update is enabled. You can also manually trigger an update:
- Click "🔄 Update Database" in the popup

## Supported Job Sites

- ✅ LinkedIn Jobs
- ✅ Indeed
- ✅ Glassdoor
- ✅ ZipRecruiter
- ✅ Wellfound (formerly AngelList Talent)

## Default Tracked Companies

The extension comes with a starter list of companies frequently reported for ghost jobs:
- Accenture (+ subsidiaries: Accenture Federal Services, Avanade)
- CVS Health (+ CVS Pharmacy, Aetna, CVS Caremark)
- Dice
- Crossover
- Revature
- TEKsystems
- Robert Half (+ Robert Half Technology, Protiviti)
- Insight Global
- Apex Systems
- ManpowerGroup (+ Manpower, Experis, Talent Solutions)
- Kelly Services (+ Kelly IT, Kelly Engineering)
- Randstad (+ Randstad Technologies, Randstad Digital)
- Aerotek

**Note**: Being on this list doesn't mean a company *never* has real jobs, just that they've been reported for ghost job practices. Always verify job postings independently.

## Data Sources

1. **GhostJobs.io**: Community-driven database (auto-scraped when available)
2. **Reddit Communities**: Reports from r/jobs, r/antiwork, r/JobSearchHacks
3. **User Reports**: Direct reports from extension users
4. **Manual Additions**: Companies you add personally

## Privacy & Security

- ✅ **No Data Collection**: This extension does NOT collect, store, or transmit any personal data
- ✅ **Local Storage Only**: All data is stored locally on your device
- ✅ **No Tracking**: No analytics or tracking of any kind
- ✅ **Open Source**: The code is fully transparent and auditable
- ✅ **Secure**: No external API calls except to GhostJobs.io (optional, can be disabled)

## Tips for Avoiding Ghost Jobs

1. **Check posting dates**: Jobs open for 30+ days are often ghosts (extension shows this!)
2. **Cross-reference**: Verify the job exists on the company's official careers page
3. **Contact directly**: Reach out to the hiring manager on LinkedIn
4. **Look for specifics**: Vague job descriptions are a red flag
5. **Check reviews**: Search Glassdoor and Reddit for company reputation
6. **Use this extension**: Let it warn you automatically!

## Advanced Features

### Job Age Thresholds

The extension uses these thresholds to determine severity:
- **0-14 days**: Recent posting (low concern)
- **14-30 days**: Moderately old (caution)
- **30-90 days**: High risk (most jobs fill within 30 days)
- **90+ days**: Critical (extremely likely to be a ghost job)

### Company Alias Matching

The extension automatically maps subsidiaries and alternate names to parent companies:
- "Accenture Technology" → Matches "Accenture"
- "CVS Pharmacy" → Matches "CVS Health"
- "Kelly IT" → Matches "Kelly Services"

This ensures you get warnings even when companies post under different names.

### Export Format

Exported history is in JSON format:
```json
{
  "exportDate": "2025-11-19T18:00:00.000Z",
  "warningHistory": [
    {
      "company": "Accenture",
      "url": "https://linkedin.com/jobs/...",
      "timestamp": 1732046400000,
      "jobAge": 45
    }
  ],
  "trackedCompanies": ["Accenture", "CVS Health", ...]
}
```

## Contributing

Contributions are welcome! To contribute:

1. Fork this repository
2. Make your changes
3. Submit a pull request

### Adding Companies

To suggest companies for the default list, please provide:
- Company name
- Evidence of ghost job practices (Reddit posts, personal experiences, etc.)
- Any known aliases or subsidiaries

## Troubleshooting

**Extension not showing warnings?**
- Make sure you're on a supported job site
- Check that the company is in your tracked list
- Try refreshing the page
- Check if the company name is being extracted (look in browser console)

**Job age not showing?**
- Some sites don't display posting dates consistently
- The extension will still warn about the company even without age data

**Auto-update not working?**
- Check that auto-update is enabled in settings
- Manual updates always work via the "Update Database" button

## Known Limitations

- Job age detection works best on LinkedIn and Indeed
- GhostJobs.io scraping depends on their site structure
- Company name extraction may fail on heavily customized job sites
- Extension requires developer mode unless published to Chrome Web Store

## Roadmap

Future planned features:
- [ ] Browser sync across devices
- [ ] More sophisticated NLP for company matching
- [ ] Integration with other job search tools
- [ ] Machine learning to predict ghost jobs
- [ ] Mobile app version
- [ ] Firefox and Edge support

## Disclaimer

This extension is provided "as is" for informational purposes. Being flagged as a potential ghost job does not guarantee a posting is fake, and legitimate companies may occasionally have jobs flagged. Always use your own judgment when applying to positions.

The extension attempts to scrape public data from GhostJobs.io. This functionality may stop working if their site structure changes. The extension will continue to function with its built-in database and user reports.

## License

MIT License - feel free to use, modify, and distribute this extension.

## Support

For issues, questions, or suggestions:
- Open an issue on GitHub
- Check [GhostJobs.io](https://ghostjobs.io/) for more information on ghost jobs
- Join the conversation on Reddit: r/jobs, r/antiwork, r/JobSearchHacks

## Acknowledgments

- Data sourced from [GhostJobs.io](https://ghostjobs.io/)
- Community reports from Reddit communities
- Built to help job seekers save time and avoid frustration
- Special thanks to all the job seekers who reported ghost jobs

---

**Remember**: Focus your energy on recent postings, verify directly with companies, and don't let ghost jobs discourage you. Real opportunities are out there! 👻🚫

**Stay safe in your job search!**
